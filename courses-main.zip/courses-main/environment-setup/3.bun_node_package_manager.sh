#!/bin/bash

# https://bun.sh/
curl -fsSL https://bun.sh/install | bash
